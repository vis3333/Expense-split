const assert = require('assert');
const L = require('../www/logic.js');

// equal split with remainder
assert.deepStrictEqual(L.splitEvenly(1000, ['a', 'b', 'c']), { a: 334, b: 333, c: 333 });

// balances: A pays 300 for A,B,C -> A +200, B -100, C -100
const e1 = { amount: 300, paidBy: 'a', split: { type: 'equal', among: ['a', 'b', 'c'] } };
let net = L.balances(['a', 'b', 'c'], [e1], []);
assert.deepStrictEqual(net, { a: 20000, b: -10000, c: -10000 });
assert.strictEqual(Object.values(net).reduce((x, y) => x + y, 0), 0);

// settlement wipes B's debt
net = L.balances(['a', 'b', 'c'], [e1], [{ from: 'b', to: 'a', amount: 100 }]);
assert.deepStrictEqual(net, { a: 10000, b: 0, c: -10000 });

// simplify chain: B owes A 100, C owes B 100 => C pays A 100
const e2 = { amount: 100, paidBy: 'a', split: { type: 'exact', values: { b: 100 } } };
const e3 = { amount: 100, paidBy: 'b', split: { type: 'exact', values: { c: 100 } } };
net = L.balances(['a', 'b', 'c'], [e2, e3], []);
assert.deepStrictEqual(L.simplify(net), [{ from: 'c', to: 'a', amount: 10000 }]);

// percent + exact fix-up
const sh = L.computeShares({ amount: 100, split: { type: 'percent', values: { a: 33.33, b: 33.33, c: 33.34 } } });
assert.strictEqual(Object.values(sh).reduce((x, y) => x + y, 0), 10000);
const ex = L.computeShares({ amount: 10, split: { type: 'exact', values: { a: 3, b: 3 } } });
assert.strictEqual(Object.values(ex).reduce((x, y) => x + y, 0), 1000);

// categorize
assert.strictEqual(L.categorize('Uber to airport'), 'travel');
assert.strictEqual(L.categorize('Pizza night'), 'food');
assert.strictEqual(L.categorize('xyz'), 'other');

// NL parser
const members = [{ id: 'me', name: 'You' }, { id: 'r', name: 'Raj' }, { id: 'a', name: 'Anu' }, { id: 'm', name: 'Meera' }];
let p = L.parseExpenseText('Dinner 1200 paid by Raj with Anu', members);
assert.strictEqual(p.amount, 1200);
assert.strictEqual(p.paidBy, 'r');
assert.strictEqual(p.desc, 'Dinner');
assert.strictEqual(p.category, 'food');
assert.deepStrictEqual(p.among.sort(), ['a', 'r']);
p = L.parseExpenseText('Taxi ₹450 split with Meera and Anu', members);
assert.strictEqual(p.amount, 450);
assert.strictEqual(p.paidBy, 'me');
assert.deepStrictEqual(p.among.sort(), ['a', 'm', 'me']);
p = L.parseExpenseText('Hotel 2.5k', members);
assert.strictEqual(p.amount, 2500);
assert.strictEqual(p.among.length, 4);

console.log('All logic tests passed');
