/* SplitAI core logic — pure functions, no DOM. All money is integer cents. */
(function (root) {
  const cents = (n) => Math.round(Number(n) * 100);

  function splitEvenly(totalC, ids) {
    const out = {};
    if (!ids.length) return out;
    const base = Math.floor(totalC / ids.length);
    let rem = totalC - base * ids.length;
    ids.forEach((id) => {
      out[id] = base + (rem > 0 ? 1 : 0);
      if (rem > 0) rem--;
    });
    return out;
  }

  // expense.split = {type:'equal', among:[ids]} | {type:'percent'|'exact', values:{id:number}}
  function computeShares(e) {
    const total = cents(e.amount);
    const s = e.split || { type: 'equal', among: [] };
    if (s.type === 'equal') return splitEvenly(total, s.among || []);
    const ids = Object.keys(s.values || {});
    const out = {};
    if (s.type === 'percent') {
      let acc = 0;
      ids.forEach((id) => {
        out[id] = Math.floor((total * Number(s.values[id])) / 100);
        acc += out[id];
      });
      let rem = total - acc;
      for (let i = 0; rem > 0 && ids.length; i = (i + 1) % ids.length, rem--) out[ids[i]]++;
      return out;
    }
    let acc = 0;
    ids.forEach((id) => {
      out[id] = cents(s.values[id]);
      acc += out[id];
    });
    if (ids.length && acc !== total) out[ids[0]] += total - acc;
    return out;
  }

  // Net balance per member in cents. Positive = is owed money, negative = owes.
  function balances(memberIds, expenses, settlements) {
    const net = {};
    memberIds.forEach((id) => (net[id] = 0));
    const add = (id, v) => (net[id] = (net[id] || 0) + v);
    expenses.forEach((e) => {
      add(e.paidBy, cents(e.amount));
      const sh = computeShares(e);
      Object.keys(sh).forEach((id) => add(id, -sh[id]));
    });
    (settlements || []).forEach((s) => {
      add(s.from, cents(s.amount));
      add(s.to, -cents(s.amount));
    });
    return net;
  }

  // Minimise number of payments (greedy). Returns [{from,to,amount(cents)}]
  function simplify(net) {
    const cr = [], db = [];
    Object.keys(net).forEach((id) => {
      if (net[id] > 0) cr.push({ id, v: net[id] });
      else if (net[id] < 0) db.push({ id, v: -net[id] });
    });
    cr.sort((a, b) => b.v - a.v);
    db.sort((a, b) => b.v - a.v);
    const out = [];
    let i = 0, j = 0;
    while (i < cr.length && j < db.length) {
      const m = Math.min(cr[i].v, db[j].v);
      if (m > 0) out.push({ from: db[j].id, to: cr[i].id, amount: m });
      cr[i].v -= m;
      db[j].v -= m;
      if (cr[i].v === 0) i++;
      if (db[j].v === 0) j++;
    }
    return out;
  }

  const CATS = {
    food: { icon: '🍽️', words: ['dinner', 'lunch', 'breakfast', 'food', 'restaurant', 'cafe', 'coffee', 'pizza', 'burger', 'biryani', 'snacks', 'drinks', 'beer', 'bar', 'swiggy', 'zomato', 'meal', 'brunch'] },
    groceries: { icon: '🛒', words: ['grocery', 'groceries', 'vegetables', 'milk', 'supermarket', 'bigbasket', 'blinkit', 'zepto', 'fruits'] },
    travel: { icon: '🚕', words: ['uber', 'ola', 'cab', 'taxi', 'petrol', 'fuel', 'flight', 'train', 'bus', 'toll', 'metro', 'ticket', 'rapido', 'parking'] },
    stay: { icon: '🏨', words: ['hotel', 'hostel', 'airbnb', 'stay', 'resort', 'room', 'rent'] },
    fun: { icon: '🎬', words: ['movie', 'cinema', 'netflix', 'concert', 'party', 'game', 'club', 'show', 'trek', 'activity', 'fun'] },
    bills: { icon: '💡', words: ['electricity', 'wifi', 'internet', 'bill', 'recharge', 'gas', 'water', 'maintenance', 'subscription'] },
    shopping: { icon: '🛍️', words: ['shopping', 'clothes', 'amazon', 'flipkart', 'gift', 'shoes'] },
    other: { icon: '🧾', words: [] },
  };

  function categorize(text) {
    const t = ' ' + String(text || '').toLowerCase() + ' ';
    for (const k of Object.keys(CATS)) {
      if (CATS[k].words.some((w) => t.includes(w))) return k;
    }
    return 'other';
  }

  function matchMember(token, members) {
    const t = token.trim().toLowerCase();
    if (!t) return null;
    if (['me', 'i', 'myself', 'you'].includes(t)) return members.find((m) => m.id === 'me') || null;
    return (
      members.find((m) => m.name.toLowerCase() === t) ||
      members.find((m) => m.name.toLowerCase().startsWith(t)) ||
      members.find((m) => t.startsWith(m.name.toLowerCase().split(' ')[0]))
    ) || null;
  }

  // Offline natural-language parser: "Dinner 1200 paid by Raj with Anu and Meera"
  function parseExpenseText(text, members) {
    const src = String(text || '').trim();
    let amount = 0;
    const am = src.match(/(?:₹|rs\.?|inr|\$|€|£|฿)?\s*(\d+(?:[.,]\d+)?)\s*(k)?\b/i);
    if (am) {
      amount = parseFloat(am[1].replace(',', '.'));
      if (am[2]) amount *= 1000;
    }
    let paidBy = 'me';
    let m = src.match(/paid\s+by\s+([a-z]+)/i) || src.match(/\b([a-z]+)\s+paid\b/i);
    if (m) {
      const mem = matchMember(m[1], members);
      if (mem) paidBy = mem.id;
    }
    if (/\bi\s+paid\b/i.test(src)) paidBy = 'me';
    let among = members.map((x) => x.id);
    const w = src.match(/\b(?:with|between|among|split(?:\s+with)?)\s+(.+)$/i);
    if (w && !/\b(everyone|all|equally)\b/i.test(w[1])) {
      const names = w[1].replace(/paid\s+by\s+[a-z]+/i, '').split(/,|&|\band\b/i);
      const picked = names.map((n) => matchMember(n.replace(/\b(equally|split)\b/gi, ''), members)).filter(Boolean);
      if (picked.length) {
        const ids = new Set(picked.map((p) => p.id));
        ids.add(paidBy);
        among = [...ids];
      }
    }
    let desc = src
      .replace(am ? am[0] : '', ' ')
      .split(/\b(?:paid|split|with|between|among)\b/i)[0]
      .replace(/^\s*(?:for|on|of)\s+/i, '')
      .replace(/\s+/g, ' ')
      .trim();
    if (!desc) desc = 'Expense';
    desc = desc.charAt(0).toUpperCase() + desc.slice(1);
    return { desc, amount, paidBy, among, category: categorize(src) };
  }

  function summarize(expenses, nameOf) {
    const total = expenses.reduce((s, e) => s + cents(e.amount), 0);
    const byCat = {}, byPayer = {};
    expenses.forEach((e) => {
      byCat[e.category || 'other'] = (byCat[e.category || 'other'] || 0) + cents(e.amount);
      byPayer[e.paidBy] = (byPayer[e.paidBy] || 0) + cents(e.amount);
    });
    const biggest = expenses.slice().sort((a, b) => b.amount - a.amount)[0] || null;
    return { total, byCat, byPayer, biggest, count: expenses.length };
  }

  function offlineInsights(expenses, nameOf, fmt) {
    const out = [];
    if (!expenses.length) return out;
    const s = summarize(expenses, nameOf);
    const cats = Object.entries(s.byCat).sort((a, b) => b[1] - a[1]);
    const [topCat, topVal] = cats[0];
    out.push({ icon: CATS[topCat].icon, title: 'Biggest category', text: `${topCat[0].toUpperCase() + topCat.slice(1)} takes ${Math.round((topVal / s.total) * 100)}% of spending (${fmt(topVal)}).` });
    const payers = Object.entries(s.byPayer).sort((a, b) => b[1] - a[1]);
    out.push({ icon: '💳', title: 'Top payer', text: `${nameOf(payers[0][0])} fronted ${fmt(payers[0][1])} — ${Math.round((payers[0][1] / s.total) * 100)}% of the total.` });
    if (s.biggest) out.push({ icon: '🔥', title: 'Largest expense', text: `${s.biggest.desc} at ${fmt(cents(s.biggest.amount))}.` });
    out.push({ icon: '📊', title: 'Average expense', text: `${fmt(Math.round(s.total / s.count))} across ${s.count} expenses.` });
    const days = new Set(expenses.map((e) => e.date)).size;
    if (days > 1) out.push({ icon: '📅', title: 'Daily average', text: `About ${fmt(Math.round(s.total / days))} per active day.` });
    return out;
  }

  const api = { cents, splitEvenly, computeShares, balances, simplify, categorize, parseExpenseText, summarize, offlineInsights, CATS, matchMember };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.Logic = api;
})(typeof window !== 'undefined' ? window : globalThis);
