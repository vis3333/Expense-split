/* SplitAI — Claude API client (runs on-device; key is the user's own, stored locally). */
(function (root) {
  const URL = 'https://api.anthropic.com/v1/messages';

  async function call({ apiKey, model, system, messages, maxTokens = 1024 }) {
    if (!apiKey) throw new Error('NO_KEY');
    const res = await fetch(URL, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true',
      },
      body: JSON.stringify({ model, max_tokens: maxTokens, system, messages }),
    });
    if (!res.ok) {
      let msg = res.status + '';
      try { msg = (await res.json()).error.message; } catch (e) {}
      throw new Error(msg);
    }
    const data = await res.json();
    return data.content.filter((b) => b.type === 'text').map((b) => b.text).join('\n').trim();
  }

  function extractJSON(text) {
    const m = text.match(/\{[\s\S]*\}/);
    if (!m) throw new Error('AI did not return JSON');
    return JSON.parse(m[0]);
  }

  // "Dinner 1200 paid by Raj with Anu" -> structured expense
  async function parseExpense(cfg, text, members) {
    const system =
      'You turn a casual sentence into one shared expense. Reply with ONLY a JSON object: ' +
      '{"desc":string,"amount":number,"paidBy":memberId,"among":[memberIds],"category":"food|groceries|travel|stay|fun|bills|shopping|other"}. ' +
      'Members (id: name): ' + members.map((m) => `${m.id}: ${m.name}`).join(', ') +
      '. The id "me" is the user ("I", "me", "you"). If no payer is given use "me". If no participants are given use everyone. ' +
      'Amounts may use k for thousand. Never invent members.';
    const out = await call({ ...cfg, system, messages: [{ role: 'user', content: text }], maxTokens: 400 });
    return extractJSON(out);
  }

  // Receipt photo -> line items
  async function scanReceipt(cfg, base64, mime) {
    const system =
      'You read photos of receipts and bills. Reply with ONLY JSON: ' +
      '{"merchant":string,"items":[{"name":string,"price":number}],"tax":number,"tip":number,"total":number,"category":"food|groceries|travel|stay|fun|bills|shopping|other"}. ' +
      'price is the line total for that item (qty x unit price). tax includes GST/VAT/service charge combined. Use 0 when absent. Numbers only, no currency symbols.';
    const out = await call({
      ...cfg,
      system,
      maxTokens: 1500,
      messages: [{
        role: 'user',
        content: [
          { type: 'image', source: { type: 'base64', media_type: mime || 'image/jpeg', data: base64 } },
          { type: 'text', text: 'Extract this receipt.' },
        ],
      }],
    });
    return extractJSON(out);
  }

  async function insights(cfg, dataJSON) {
    const system =
      'You are a friendly money coach inside a bill-splitting app. Given the spending data, write 3-5 short, specific insights ' +
      '(trends, unusual expenses, who is fronting too much, one practical suggestion). Use plain sentences with one emoji each, one per line. ' +
      'Use only the data provided. No preamble.';
    return call({ ...cfg, system, messages: [{ role: 'user', content: dataJSON }], maxTokens: 600 });
  }

  async function chat(cfg, dataJSON, history) {
    const system =
      'You are SplitAI, the assistant inside a Splitwise-style expense app. Answer questions about the user\'s groups, expenses and balances ' +
      'using ONLY the JSON data below. Amounts are in the stated currency; balances: positive means the person is owed, negative means they owe. ' +
      'Be concise (under 80 words), friendly, and show numbers. If something is not in the data, say so.\n\nDATA:\n' + dataJSON;
    return call({ ...cfg, system, messages: history, maxTokens: 500 });
  }

  root.AI = { call, parseExpense, scanReceipt, insights, chat };
})(typeof window !== 'undefined' ? window : globalThis);
