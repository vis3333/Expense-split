/* SplitAI — UI. Vanilla JS, single file, no build step. */
(function () {
  const L = window.Logic, AI = window.AI;
  const KEY = 'splitai_v1';
  const COLORS = ['#7c5cff', '#00b8d9', '#ff6b8b', '#f59e0b', '#10b981', '#ec4899', '#6366f1', '#14b8a6'];
  const EMOJIS = ['🏖️', '🏠', '✈️', '🍕', '🎉', '🏔️', '🚗', '💼', '🎓', '❤️'];
  const CURRENCIES = ['₹', '$', '€', '£', '฿', '¥', 'د.إ'];

  const blank = () => ({ people: [], groups: [], expenses: [], settlements: [], settings: { apiKey: '', model: 'claude-haiku-5-5', currency: '₹' } });
  function load() {
    try { const s = JSON.parse(localStorage.getItem(KEY)); if (s && s.groups) { s.settings = Object.assign(blank().settings, s.settings); return s; } } catch (e) {}
    return blank();
  }
  let S = load();
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} };
  const ui = { tab: 'home', gid: null, gtab: 'expenses', chat: [], busy: false, aiText: {} };
  let draft = null, receipt = null;

  const $ = (id) => document.getElementById(id);
  const uid = () => Math.random().toString(36).slice(2, 9);
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const today = () => new Date().toISOString().slice(0, 10);
  const daysAgo = (n) => new Date(Date.now() - n * 864e5).toISOString().slice(0, 10);
  const fmt = (c) => {
    const v = Math.abs(c) / 100;
    return S.settings.currency + v.toLocaleString('en-IN', { minimumFractionDigits: Math.abs(c) % 100 ? 2 : 0, maximumFractionDigits: 2 });
  };
  const nameOf = (id) => (id === 'me' ? 'You' : (S.people.find((p) => p.id === id) || { name: '?' }).name);
  const colorOf = (id) => { let h = 0; for (const ch of id) h = (h * 31 + ch.charCodeAt(0)) >>> 0; return COLORS[h % COLORS.length]; };
  const avatar = (id, sm) => `<div class="avatar${sm ? ' sm' : ''}" style="background:${colorOf(id)}">${esc(nameOf(id).slice(0, 1).toUpperCase())}</div>`;
  const group = (id) => S.groups.find((g) => g.id === id);
  const membersOf = (g) => g.members.map((id) => ({ id, name: nameOf(id) }));
  const dateLabel = (d) => new Date(d + 'T00:00:00').toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });

  function gData(g) {
    const ex = S.expenses.filter((e) => e.gid === g.id);
    const st = S.settlements.filter((s) => s.gid === g.id);
    return { ex, st, net: L.balances(g.members, ex, st) };
  }

  let toastT;
  function toast(msg) { const t = $('toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), 2600); }
  function openSheet(html) { $('sheet').innerHTML = '<div class="grab"></div>' + html; $('sheetbg').classList.add('open'); }
  function closeSheet() { $('sheetbg').classList.remove('open'); draft = null; receipt = null; }
  const spin = '<span class="loader"></span>';

  /* ---------------- views ---------------- */
  function vHome() {
    let owed = 0, owe = 0;
    S.groups.forEach((g) => { const n = gData(g).net.me || 0; if (n > 0) owed += n; else owe -= n; });
    const overall = owed - owe;
    const list = S.groups.map((g) => {
      const n = gData(g).net.me || 0;
      const bal = n > 0 ? `<span class="pos">you're owed ${fmt(n)}</span>` : n < 0 ? `<span class="neg">you owe ${fmt(n)}</span>` : '<span class="muted">settled up</span>';
      return `<div class="card tap row" data-a="openGroup" data-id="${g.id}">
        <div class="emoji">${esc(g.emoji)}</div>
        <div class="grow"><div style="font-weight:700">${esc(g.name)}</div><div class="small">${bal}</div></div>
        <div class="stack">${g.members.slice(0, 4).map((m) => avatar(m, true)).join('')}</div></div>`;
    }).join('');
    return `<div class="top"><div class="logo">SplitAI ✦</div></div>
      <div class="hero"><div class="small" style="font-weight:700;opacity:.7">${overall >= 0 ? 'YOU ARE OWED' : 'YOU OWE'}</div>
        <div class="big">${fmt(overall)}</div>
        <div class="pills"><div class="pill">⬆ Owed ${fmt(owed)}</div><div class="pill">⬇ You owe ${fmt(owe)}</div></div></div>
      <h2>Your groups</h2>
      ${list || `<div class="empty"><div class="big">🧾</div><p>No groups yet.<br>Create one with the + button, or explore with sample data.</p><button class="btn ghost" data-a="demo">Load sample data</button></div>`}`;
  }

  function vGroup() {
    const g = group(ui.gid); if (!g) { ui.gid = null; return vHome(); }
    const d = gData(g);
    const total = d.ex.reduce((s, e) => s + L.cents(e.amount), 0);
    const mine = d.net.me || 0;
    let body = '';
    if (ui.gtab === 'expenses') body = vExpenses(g, d);
    else if (ui.gtab === 'balances') body = vBalances(g, d);
    else body = vInsightBlock(d.ex, 'g' + g.id);
    return `<div class="top"><button class="icon-btn" data-a="back">←</button><div style="font-weight:800;font-size:18px">${esc(g.emoji)} ${esc(g.name)}</div><button class="icon-btn" data-a="gmenu">⋯</button></div>
      <div class="hero"><div class="small" style="font-weight:700;opacity:.7">GROUP SPENDING</div><div class="big">${fmt(total)}</div>
        <div class="pills"><div class="pill">${mine > 0 ? `You're owed ${fmt(mine)}` : mine < 0 ? `You owe ${fmt(mine)}` : 'You are settled up'}</div><div class="pill">${d.ex.length} expenses</div></div></div>
      <div class="seg">${['expenses', 'balances', 'insights'].map((t) => `<button class="${ui.gtab === t ? 'on' : ''}" data-a="gtab" data-t="${t}">${t[0].toUpperCase() + t.slice(1)}</button>`).join('')}</div>${body}`;
  }

  function vExpenses(g, d) {
    if (!d.ex.length) return '<div class="empty"><div class="big">💸</div><p>No expenses yet.<br>Tap + to add one — or just type it in plain words.</p></div>';
    const sorted = d.ex.slice().sort((a, b) => (b.date + b.id).localeCompare(a.date + a.id));
    let last = '', html = '';
    sorted.forEach((e) => {
      if (e.date !== last) { html += `<div class="date-h">${dateLabel(e.date)}</div>`; last = e.date; }
      const sh = L.computeShares(e), my = sh.me || 0, tot = L.cents(e.amount);
      const right = e.paidBy === 'me' ? (tot - my > 0 ? `<div class="pos" style="font-weight:700">you lent<br>${fmt(tot - my)}</div>` : '<div class="muted small">no split</div>')
        : my > 0 ? `<div class="neg" style="font-weight:700">you owe<br>${fmt(my)}</div>` : '<div class="muted small">not involved</div>';
      html += `<div class="card tap row" data-a="viewExp" data-id="${e.id}"><div class="emoji">${L.CATS[e.category || 'other'].icon}</div>
        <div class="grow"><div class="ellipsis" style="font-weight:700">${esc(e.desc)}</div><div class="small muted">${esc(nameOf(e.paidBy))} paid ${fmt(tot)}</div></div><div style="text-align:right;font-size:13px">${right}</div></div>`;
    });
    return html;
  }

  function vBalances(g, d) {
    const pay = L.simplify(d.net);
    const rows = g.members.map((id) => { const n = d.net[id] || 0;
      return `<div class="item">${avatar(id)}<div class="grow"><b>${esc(nameOf(id))}</b></div><div class="${n > 0 ? 'pos' : n < 0 ? 'neg' : 'muted'}" style="font-weight:700">${n > 0 ? 'gets ' + fmt(n) : n < 0 ? 'owes ' + fmt(n) : 'settled'}</div></div>`; }).join('');
    const pays = pay.map((p, i) => `<div class="item">${avatar(p.from, true)}<div class="grow small"><b>${esc(nameOf(p.from))}</b> pays <b>${esc(nameOf(p.to))}</b><div class="${'pos'}" style="font-weight:700;font-size:15px">${fmt(p.amount)}</div></div>
      <button class="btn sm" data-a="markPaid" data-i="${i}">Mark paid</button></div>`).join('');
    const hist = d.st.slice().reverse().map((s) => `<div class="item small"><span>✅</span><div class="grow">${esc(nameOf(s.from))} paid ${esc(nameOf(s.to))} <b>${fmt(L.cents(s.amount))}</b></div><span class="muted">${dateLabel(s.date)}</span></div>`).join('');
    return `<div class="card">${rows}</div><h2>Simplest way to settle</h2><div class="card">${pays || '<div class="muted" style="padding:6px 0">🎉 Everyone is settled up.</div>'}</div>
      ${hist ? `<h2>Payments made</h2><div class="card">${hist}</div>` : ''}
      <button class="btn ghost block" data-a="addMember">+ Add a member</button>`;
  }

  function vInsightBlock(exps, key) {
    if (!exps.length) return '<div class="empty"><div class="big">📊</div><p>Add some expenses to see insights.</p></div>';
    const s = L.summarize(exps);
    const cats = Object.entries(s.byCat).sort((a, b) => b[1] - a[1]);
    const bars = cats.map(([c, v]) => `<div style="margin-bottom:12px"><div class="row between small"><span>${L.CATS[c].icon} ${c[0].toUpperCase() + c.slice(1)}</span><b>${fmt(v)}</b></div><div class="bar"><i style="width:${Math.round((v / cats[0][1]) * 100)}%"></i></div></div>`).join('');
    const cards = L.offlineInsights(exps, nameOf, fmt).map((i) => `<div class="card row"><div class="emoji">${i.icon}</div><div class="grow"><b>${esc(i.title)}</b><div class="small muted">${esc(i.text)}</div></div></div>`).join('');
    const ai = ui.aiText[key];
    return `<div class="card"><div style="font-weight:700;margin-bottom:12px">Where the money went</div>${bars}</div>${cards}
      <div class="ai-bar"><div style="font-weight:800"><span class="spark">✨</span> AI money coach</div>
      <div class="small muted" style="margin-top:4px">Trends, odd spends and suggestions written just for this data.</div>
      ${ai ? `<div style="margin-top:10px;white-space:pre-wrap;font-size:15px;line-height:1.5">${esc(ai)}</div>` : ''}
      <div class="row"><button class="btn sm" id="aiins" data-a="aiInsights" data-k="${key}">${ai ? 'Refresh insights' : 'Generate insights'}</button></div></div>`;
  }

  function vInsights() {
    return `<div class="top"><div class="logo">Insights</div></div>${vInsightBlock(S.expenses, 'all')}`;
  }

  function vChat() {
    const chips = ['Who owes me money?', 'What did we spend the most on?', 'Total spent this month?'];
    return `<div class="top"><div class="logo">Assistant ✨</div></div>
      <div id="msgs">${chatHTML()}</div>
      <div class="chips" style="margin-top:14px">${chips.map((c) => `<button class="chip" data-a="chatQuick" data-q="${esc(c)}">${esc(c)}</button>`).join('')}</div>
      <div style="height:70px"></div>
      <div class="chatbar"><input id="chatin" placeholder="Ask about your expenses…" enterkeyhint="send"><button class="btn" data-a="chatSend">➤</button></div>`;
  }
  const chatHTML = () => (ui.chat.length ? ui.chat.map((m) => `<div class="bubble ${m.role === 'user' ? 'me' : 'ai'}">${esc(m.content)}</div>`).join('') :
    `<div class="bubble ai">Hi! I can answer questions about your groups, balances and spending. Try one of the suggestions below.${S.settings.apiKey ? '' : '\n\nTip: add your Claude API key in More → AI to unlock full conversations.'}</div>`) +
    (ui.busy ? `<div class="bubble ai">${spin.replace('rgba(0,0,0,.25)', '')}Thinking…</div>` : '');

  function vSettings() {
    const st = S.settings;
    return `<div class="top"><div class="logo">More</div></div>
      <div class="card"><div style="font-weight:800;margin-bottom:4px">✨ AI features</div>
        <div class="small muted">Receipt scan, plain-English entry, insights and chat use the Claude API with your own key. The key stays on this phone and requests go straight to Anthropic. Without a key, offline smart-entry and basic insights still work.</div>
        <label>Claude API key</label><input type="password" data-s="apiKey" value="${esc(st.apiKey)}" placeholder="sk-ant-…" autocomplete="off">
        <label>Model</label><select data-s="model"><option value="claude-haiku-5-5" ${st.model === 'claude-haiku-5-5' ? 'selected' : ''}>Claude Haiku 5.5 — fast &amp; cheap</option><option value="claude-sonnet-5-5" ${st.model === 'claude-sonnet-5-5' ? 'selected' : ''}>Claude Sonnet 5.5 — smarter</option></select></div>
      <div class="card"><label style="margin-top:0">Currency</label><select data-s="currency">${CURRENCIES.map((c) => `<option ${c === st.currency ? 'selected' : ''}>${c}</option>`).join('')}</select></div>
      <div class="card"><div style="font-weight:800;margin-bottom:10px">Your data</div>
        <div class="two"><button class="btn ghost" data-a="backup">Copy backup</button><button class="btn ghost" data-a="restore">Restore</button></div>
        <div class="two" style="margin-top:10px"><button class="btn ghost" data-a="demo">Load sample data</button><button class="btn danger" data-a="reset">Erase all</button></div></div>
      <p class="small muted" style="text-align:center">SplitAI · data is stored only on this device</p>`;
  }

  function render() {
    const app = $('app');
    let html;
    if (ui.tab === 'home') html = ui.gid ? vGroup() : vHome();
    else if (ui.tab === 'chat') html = vChat();
    else if (ui.tab === 'insights') html = vInsights();
    else html = vSettings();
    app.innerHTML = html;
    const tabs = [['home', '🏠', 'Groups'], ['chat', '✨', 'Assistant'], ['insights', '📊', 'Insights'], ['settings', '⚙️', 'More']];
    $('nav').innerHTML = tabs.map(([k, i, l]) => `<button class="${ui.tab === k ? 'on' : ''}" data-a="tab" data-t="${k}"><span>${i}</span>${l}</button>`).join('');
    $('fab').innerHTML = ui.tab === 'home' ? `<button class="fab" data-a="${ui.gid ? 'addExpense' : 'newGroup'}">+</button>` : '';
    if (ui.tab === 'chat') { const m = $('msgs'); window.scrollTo(0, document.body.scrollHeight); }
  }

  /* ---------------- expense sheet ---------------- */
  function newDraft(g) {
    return { gid: g.id, desc: '', amount: '', paidBy: 'me', type: 'equal', among: g.members.slice(), values: {}, category: 'other', date: today() };
  }
  function expenseSheet() {
    const g = group(draft.gid), mem = membersOf(g);
    const catOpts = Object.keys(L.CATS).map((c) => `<option value="${c}" ${draft.category === c ? 'selected' : ''}>${L.CATS[c].icon} ${c}</option>`).join('');
    let who;
    if (draft.type === 'equal') who = `<div class="chips">${mem.map((m) => `<button class="chip ${draft.among.includes(m.id) ? 'on' : ''}" data-a="toggle" data-id="${m.id}">${esc(m.name)}</button>`).join('')}</div>`;
    else who = mem.map((m) => `<div class="row" style="margin-bottom:8px">${avatar(m.id, true)}<div class="grow">${esc(m.name)}</div><input style="width:120px" type="number" inputmode="decimal" data-v="${m.id}" value="${draft.values[m.id] || ''}" placeholder="${draft.type === 'percent' ? '%' : '0'}"></div>`).join('') + '<div class="small muted" id="hint"></div>';
    openSheet(`<h1 style="font-size:22px;margin-bottom:12px">New expense</h1>
      <div class="ai-bar"><div style="font-weight:800"><span class="spark">✨</span> Type it naturally</div>
        <input id="q" style="margin-top:8px" placeholder="Dinner 1200 paid by Raj with Anu" enterkeyhint="go">
        <div class="row"><button class="btn sm grow" id="fillbtn" data-a="aiFill">Fill for me</button><button class="btn sm ghost grow" data-a="scan">📷 Scan receipt</button></div></div>
      <label>Description</label><input data-f="desc" value="${esc(draft.desc)}" placeholder="What was it for?">
      <div class="two"><div><label>Amount (${esc(S.settings.currency)})</label><input data-f="amount" type="number" inputmode="decimal" value="${esc(draft.amount)}" placeholder="0"></div>
        <div><label>Date</label><input data-f="date" type="date" value="${draft.date}"></div></div>
      <div class="two"><div><label>Paid by</label><select data-f="paidBy">${mem.map((m) => `<option value="${m.id}" ${draft.paidBy === m.id ? 'selected' : ''}>${esc(m.name)}</option>`).join('')}</select></div>
        <div><label>Category</label><select data-f="category">${catOpts}</select></div></div>
      <label>Split</label><div class="seg" style="margin:0 0 12px">${[['equal', 'Equally'], ['exact', 'Exact'], ['percent', 'Percent']].map(([t, l]) => `<button class="${draft.type === t ? 'on' : ''}" data-a="stype" data-t="${t}">${l}</button>`).join('')}</div>
      ${who}<button class="btn block" style="margin-top:16px" data-a="saveExp">Save expense</button>`);
    updateHint();
  }
  function updateHint() {
    const h = $('hint'); if (!h || !draft) return;
    const sum = Object.values(draft.values).reduce((s, v) => s + (parseFloat(v) || 0), 0);
    if (draft.type === 'percent') h.textContent = `Total ${sum.toFixed(2)}% of 100%`;
    else h.textContent = `Assigned ${S.settings.currency}${sum.toFixed(2)} of ${S.settings.currency}${(parseFloat(draft.amount) || 0).toFixed(2)}`;
  }
  function applyParsed(p) {
    const g = group(draft.gid), ids = g.members;
    if (p.desc) draft.desc = p.desc;
    if (p.amount) draft.amount = String(p.amount);
    if (ids.includes(p.paidBy)) draft.paidBy = p.paidBy;
    const among = (p.among || []).filter((x) => ids.includes(x));
    if (among.length) { draft.among = among; draft.type = 'equal'; }
    if (L.CATS[p.category]) draft.category = p.category;
  }
  const aiCfg = () => ({ apiKey: S.settings.apiKey, model: S.settings.model });

  async function fileToB64(file, max = 1600) {
    return new Promise((res, rej) => {
      const img = new Image(), url = URL.createObjectURL(file);
      img.onload = () => { const r = Math.min(1, max / Math.max(img.width, img.height)); const c = document.createElement('canvas');
        c.width = Math.round(img.width * r); c.height = Math.round(img.height * r); c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        URL.revokeObjectURL(url); res(c.toDataURL('image/jpeg', 0.85).split(',')[1]); };
      img.onerror = rej; img.src = url;
    });
  }

  /* ---------------- receipt sheet ---------------- */
  function receiptSplit() {
    const per = {}; let sub = 0;
    receipt.items.forEach((it) => { const c = L.cents(it.price); sub += c; const sp = L.splitEvenly(c, it.who); Object.keys(sp).forEach((id) => (per[id] = (per[id] || 0) + sp[id])); });
    const extra = L.cents(receipt.tax) + L.cents(receipt.tip);
    const ids = Object.keys(per), out = {}; let acc = 0;
    ids.forEach((id) => { out[id] = per[id] + (sub ? Math.floor((extra * per[id]) / sub) : 0); acc += out[id]; });
    let rem = sub + extra - acc;
    ids.slice().sort((a, b) => per[b] - per[a]).forEach((id) => { if (rem > 0) { out[id]++; rem--; } });
    return { out, total: sub + extra };
  }
  function receiptSheet() {
    const g = group(receipt.gid), mem = membersOf(g), r = receiptSplit();
    openSheet(`<h1 style="font-size:22px">🧾 ${esc(receipt.merchant || 'Receipt')}</h1><div class="small muted" style="margin-bottom:8px">Tap names to choose who shared each item. Tax and tip are split in proportion.</div>
      ${receipt.items.map((it, i) => `<div class="card"><div class="row between"><b class="ellipsis">${esc(it.name)}</b><b>${fmt(L.cents(it.price))}</b></div>
        <div class="chips" style="margin-top:8px">${mem.map((m) => `<button class="chip ${it.who.includes(m.id) ? 'on' : ''}" data-a="rToggle" data-i="${i}" data-id="${m.id}">${esc(m.name)}</button>`).join('')}</div></div>`).join('')}
      <div class="two"><div><label>Tax / charges</label><input type="number" inputmode="decimal" data-r="tax" value="${receipt.tax}"></div><div><label>Tip</label><input type="number" inputmode="decimal" data-r="tip" value="${receipt.tip}"></div></div>
      <label>Paid by</label><select data-r="paidBy">${mem.map((m) => `<option value="${m.id}" ${receipt.paidBy === m.id ? 'selected' : ''}>${esc(m.name)}</option>`).join('')}</select>
      <div class="card" style="margin-top:14px">${Object.keys(r.out).map((id) => `<div class="row between small" style="padding:3px 0"><span>${esc(nameOf(id))}</span><b>${fmt(r.out[id])}</b></div>`).join('')}
        <div class="row between" style="border-top:1px solid var(--line);margin-top:8px;padding-top:8px"><b>Total</b><b>${fmt(r.total)}</b></div></div>
      <button class="btn block" data-a="rCreate">Create expense</button>`);
  }

  /* ---------------- chat ---------------- */
  function chatData() {
    return JSON.stringify({
      currency: S.settings.currency, today: today(), user: 'You',
      groups: S.groups.map((g) => { const d = gData(g); const names = (id) => nameOf(id);
        return { name: g.name, members: g.members.map(names), balances: Object.fromEntries(Object.entries(d.net).map(([k, v]) => [names(k), v / 100])),
          suggestedPayments: L.simplify(d.net).map((p) => ({ from: names(p.from), to: names(p.to), amount: p.amount / 100 })),
          expenses: d.ex.slice(-80).map((e) => ({ desc: e.desc, amount: e.amount, paidBy: names(e.paidBy), date: e.date, category: e.category, sharedBy: Object.keys(L.computeShares(e)).map(names) })) }; }),
    });
  }
  function offlineAnswer(q) {
    q = q.toLowerCase();
    if (/owe|settle|balance|who/.test(q)) {
      const lines = [];
      S.groups.forEach((g) => { L.simplify(gData(g).net).forEach((p) => lines.push(`${g.emoji} ${nameOf(p.from)} → ${nameOf(p.to)}: ${fmt(p.amount)}`)); });
      return lines.length ? 'Here is what is pending:\n' + lines.join('\n') : 'Everyone is settled up 🎉';
    }
    if (/most|biggest|largest|highest/.test(q)) {
      const b = S.expenses.slice().sort((a, c) => c.amount - a.amount)[0];
      return b ? `Your largest expense is "${b.desc}" at ${fmt(L.cents(b.amount))} in ${group(b.gid) ? group(b.gid).name : 'a group'}.` : 'No expenses yet.';
    }
    if (/total|spent|spend/.test(q)) {
      const ym = today().slice(0, 7), m = S.expenses.filter((e) => e.date.startsWith(ym)).reduce((s, e) => s + L.cents(e.amount), 0);
      const all = S.expenses.reduce((s, e) => s + L.cents(e.amount), 0);
      return `This month: ${fmt(m)}. All time: ${fmt(all)}.`;
    }
    return 'I can answer simple questions offline. Add your Claude API key in More → AI for open-ended chat about your spending.';
  }
  async function sendChat(text) {
    text = text.trim(); if (!text || ui.busy) return;
    ui.chat.push({ role: 'user', content: text }); ui.busy = true; refreshMsgs();
    try {
      let ans;
      if (S.settings.apiKey) ans = await AI.chat(aiCfg(), chatData(), ui.chat.slice(-12).map((m) => ({ role: m.role, content: m.content })));
      else ans = offlineAnswer(text);
      ui.chat.push({ role: 'assistant', content: ans });
    } catch (e) { ui.chat.push({ role: 'assistant', content: 'Sorry, that failed: ' + e.message }); }
    ui.busy = false; refreshMsgs();
  }
  function refreshMsgs() { const m = $('msgs'); if (m) { m.innerHTML = chatHTML(); window.scrollTo(0, document.body.scrollHeight); } }

  /* ---------------- actions ---------------- */
  const A = {
    tab(d) { ui.tab = d.t; if (d.t !== 'home') ui.gid = null; render(); },
    openGroup(d) { ui.gid = d.id; ui.gtab = 'expenses'; render(); window.scrollTo(0, 0); },
    back() { ui.gid = null; render(); },
    gtab(d) { ui.gtab = d.t; render(); },
    newGroup() {
      openSheet(`<h1 style="font-size:22px">New group</h1><label>Name</label><input id="gname" placeholder="Goa trip, Flat, Office lunch…">
        <label>Icon</label><div class="chips" id="emojis">${EMOJIS.map((e, i) => `<button class="chip ${i === 0 ? 'on' : ''}" data-a="pickEmoji" data-e="${e}">${e}</button>`).join('')}</div>
        <label>Friends (comma separated)</label><input id="gmem" placeholder="Raj, Anu, Meera"><button class="btn block" style="margin-top:18px" data-a="saveGroup">Create group</button>`);
    },
    pickEmoji(d, t) { document.querySelectorAll('#emojis .chip').forEach((c) => c.classList.remove('on')); t.classList.add('on'); },
    saveGroup() {
      const name = $('gname').value.trim(); if (!name) return toast('Give the group a name');
      const emoji = (document.querySelector('#emojis .chip.on') || {}).dataset ? document.querySelector('#emojis .chip.on').dataset.e : '🏖️';
      const ids = ['me'];
      $('gmem').value.split(',').map((s) => s.trim()).filter(Boolean).forEach((n) => { ids.push(personId(n)); });
      S.groups.push({ id: uid(), name, emoji, members: [...new Set(ids)] }); save(); closeSheet(); render(); toast('Group created');
    },
    gmenu() {
      const g = group(ui.gid);
      openSheet(`<h1 style="font-size:22px">${esc(g.emoji)} ${esc(g.name)}</h1><p class="muted small">Members: ${g.members.map((m) => esc(nameOf(m))).join(', ')}</p>
        <button class="btn danger block" data-a="delGroup">Delete this group</button>`);
    },
    delGroup() {
      const id = ui.gid; S.groups = S.groups.filter((g) => g.id !== id); S.expenses = S.expenses.filter((e) => e.gid !== id); S.settlements = S.settlements.filter((s) => s.gid !== id);
      ui.gid = null; save(); closeSheet(); render(); toast('Group deleted');
    },
    addMember() { openSheet(`<h1 style="font-size:22px">Add member</h1><label>Name</label><input id="mname" placeholder="Name"><button class="btn block" style="margin-top:16px" data-a="saveMember">Add</button>`); },
    saveMember() { const n = $('mname').value.trim(); if (!n) return; const g = group(ui.gid); const id = personId(n); if (!g.members.includes(id)) g.members.push(id); save(); closeSheet(); render(); },

    addExpense() { draft = newDraft(group(ui.gid)); expenseSheet(); },
    stype(d) { draft.type = d.t; draft.values = {}; expenseSheet(); },
    toggle(d) { const i = draft.among.indexOf(d.id); if (i >= 0) draft.among.splice(i, 1); else draft.among.push(d.id); expenseSheet(); },
    async aiFill() {
      const text = $('q').value.trim(); if (!text) return toast('Type something like "Dinner 1200 paid by Raj"');
      const btn = $('fillbtn'); btn.innerHTML = spin + 'Reading…';
      const g = group(draft.gid), mem = membersOf(g);
      try {
        const p = S.settings.apiKey ? await AI.parseExpense(aiCfg(), text, mem) : L.parseExpenseText(text, mem);
        applyParsed(p); expenseSheet(); toast(S.settings.apiKey ? 'Filled with AI ✨' : 'Filled — add an API key for smarter parsing');
      } catch (e) { applyParsed(L.parseExpenseText(text, mem)); expenseSheet(); toast('AI unavailable (' + e.message + '). Used offline parser.'); }
    },
    scan() {
      if (!S.settings.apiKey) return toast('Add your Claude API key in More → AI to scan receipts');
      const gid = draft ? draft.gid : ui.gid; $('file').dataset.gid = gid; $('file').value = ''; $('file').click();
    },
    saveExp() {
      const amount = parseFloat(draft.amount); if (!draft.desc.trim()) return toast('Add a description'); if (!(amount > 0)) return toast('Enter an amount');
      let split;
      if (draft.type === 'equal') { if (!draft.among.length) return toast('Pick who shares this'); split = { type: 'equal', among: draft.among.slice() }; }
      else {
        const values = {}; Object.keys(draft.values).forEach((k) => { const v = parseFloat(draft.values[k]); if (v > 0) values[k] = v; });
        const sum = Object.values(values).reduce((a, b) => a + b, 0);
        if (!Object.keys(values).length) return toast('Enter each person\'s share');
        if (draft.type === 'percent' && Math.abs(sum - 100) > 0.01) return toast('Percentages must add up to 100');
        if (draft.type === 'exact' && Math.abs(sum - amount) > 0.01) return toast('Shares must add up to the amount');
        split = { type: draft.type, values };
      }
      S.expenses.push({ id: uid(), gid: draft.gid, desc: draft.desc.trim(), amount, paidBy: draft.paidBy, split, category: draft.category, date: draft.date || today() });
      save(); closeSheet(); render(); toast('Expense added');
    },
    viewExp(d) {
      const e = S.expenses.find((x) => x.id === d.id), sh = L.computeShares(e);
      openSheet(`<div class="row"><div class="emoji">${L.CATS[e.category || 'other'].icon}</div><div><h1 style="font-size:22px">${esc(e.desc)}</h1><div class="muted small">${dateLabel(e.date)}</div></div></div>
        <div class="hero" style="margin:16px 0"><div class="small" style="font-weight:700;opacity:.7">${esc(nameOf(e.paidBy)).toUpperCase()} PAID</div><div class="big" style="margin-bottom:0">${fmt(L.cents(e.amount))}</div></div>
        <div class="card">${Object.keys(sh).map((id) => `<div class="item">${avatar(id, true)}<div class="grow">${esc(nameOf(id))}</div><b>${fmt(sh[id])}</b></div>`).join('')}</div>
        <button class="btn danger block" data-a="delExp" data-id="${e.id}">Delete expense</button>`);
    },
    delExp(d) { S.expenses = S.expenses.filter((e) => e.id !== d.id); save(); closeSheet(); render(); toast('Deleted'); },
    markPaid(d) {
      const g = group(ui.gid), p = L.simplify(gData(g).net)[+d.i]; if (!p) return;
      S.settlements.push({ id: uid(), gid: g.id, from: p.from, to: p.to, amount: p.amount / 100, date: today() }); save(); render(); toast('Payment recorded 🎉');
    },

    rToggle(d) { const it = receipt.items[+d.i], k = it.who.indexOf(d.id); if (k >= 0) it.who.splice(k, 1); else it.who.push(d.id); if (!it.who.length) it.who.push(d.id); receiptSheet(); },
    rCreate() {
      const r = receiptSplit(); if (!r.total) return toast('Nothing to split');
      const values = {}; Object.keys(r.out).forEach((id) => (values[id] = r.out[id] / 100));
      S.expenses.push({ id: uid(), gid: receipt.gid, desc: receipt.merchant || 'Receipt', amount: r.total / 100, paidBy: receipt.paidBy, split: { type: 'exact', values }, category: L.CATS[receipt.category] ? receipt.category : 'food', date: today() });
      save(); closeSheet(); render(); toast('Receipt split added 🧾');
    },

    async aiInsights(d) {
      const btn = $('aiins'); btn.innerHTML = spin + 'Thinking…';
      const ex = d.k === 'all' ? S.expenses : S.expenses.filter((e) => 'g' + e.gid === d.k);
      if (!S.settings.apiKey) { ui.aiText[d.k] = '🔑 Add your Claude API key in More → AI to get personalised insights.'; return render(); }
      try {
        const data = JSON.stringify({ currency: S.settings.currency, expenses: ex.map((e) => ({ desc: e.desc, amount: e.amount, paidBy: nameOf(e.paidBy), date: e.date, category: e.category, sharedBy: Object.keys(L.computeShares(e)).map(nameOf) })) });
        ui.aiText[d.k] = await AI.insights(aiCfg(), data);
      } catch (e) { ui.aiText[d.k] = 'Could not reach AI: ' + e.message; }
      render();
    },
    chatSend() { const i = $('chatin'); const t = i.value; i.value = ''; sendChat(t); },
    chatQuick(d) { sendChat(d.q); },

    demo() { loadDemo(); closeSheet(); render(); toast('Sample data loaded'); },
    reset() { openSheet(`<h1 style="font-size:22px">Erase everything?</h1><p class="muted">All groups, expenses and settings on this device will be deleted.</p><button class="btn danger block" data-a="doReset">Yes, erase all</button><button class="btn ghost block" style="margin-top:10px" data-a="close">Cancel</button>`); },
    doReset() { S = blank(); save(); ui.gid = null; ui.chat = []; ui.aiText = {}; closeSheet(); render(); toast('Erased'); },
    close() { closeSheet(); },
    backup() {
      const copy = Object.assign({}, S, { settings: Object.assign({}, S.settings, { apiKey: '' }) }); const txt = JSON.stringify(copy);
      (navigator.clipboard ? navigator.clipboard.writeText(txt) : Promise.reject()).then(() => toast('Backup copied — paste it somewhere safe'), () => toast('Could not copy'));
    },
    restore() { openSheet(`<h1 style="font-size:22px">Restore backup</h1><label>Paste backup text</label><textarea id="rtxt" rows="6"></textarea><button class="btn block" style="margin-top:14px" data-a="doRestore">Restore</button>`); },
    doRestore() {
      try { const o = JSON.parse($('rtxt').value); if (!o.groups) throw 0; const key = S.settings.apiKey; S = Object.assign(blank(), o); S.settings = Object.assign(blank().settings, o.settings, { apiKey: key }); save(); closeSheet(); render(); toast('Restored'); }
      catch (e) { toast('That does not look like a SplitAI backup'); }
    },
  };

  function personId(name) {
    const hit = S.people.find((p) => p.name.toLowerCase() === name.toLowerCase());
    if (hit) return hit.id; const p = { id: uid(), name }; S.people.push(p); return p.id;
  }

  function loadDemo() {
    S.people = []; S.groups = []; S.expenses = []; S.settlements = [];
    const raj = personId('Raj'), anu = personId('Anu'), meera = personId('Meera'), kabir = personId('Kabir');
    const goa = { id: uid(), name: 'Goa Trip', emoji: '🏖️', members: ['me', raj, anu, meera] };
    const flat = { id: uid(), name: 'Flat 4B', emoji: '🏠', members: ['me', kabir, anu] };
    S.groups.push(goa, flat);
    const eq = (ids) => ({ type: 'equal', among: ids });
    const add = (g, desc, amount, paidBy, cat, ago, ids) => S.expenses.push({ id: uid(), gid: g.id, desc, amount, paidBy, split: eq(ids || g.members), category: cat, date: daysAgo(ago) });
    add(goa, 'Flights', 18400, 'me', 'travel', 21); add(goa, 'Beach villa', 24000, raj, 'stay', 20); add(goa, 'Scooter rental', 2400, anu, 'travel', 19);
    add(goa, 'Seafood dinner', 5200, meera, 'food', 19); add(goa, 'Club night', 6800, 'me', 'fun', 18, ['me', raj, meera]); add(goa, 'Breakfast shack', 1480, raj, 'food', 18);
    add(flat, 'Rent', 36000, kabir, 'stay', 12); add(flat, 'Electricity bill', 2310, 'me', 'bills', 9); add(flat, 'Groceries', 3240, anu, 'groceries', 5); add(flat, 'WiFi', 999, kabir, 'bills', 3);
    S.settlements.push({ id: uid(), gid: goa.id, from: meera, to: raj, amount: 2000, date: daysAgo(10) });
    save();
  }

  /* ---------------- events ---------------- */
  document.addEventListener('click', (e) => {
    const t = e.target.closest('[data-a]');
    if (!t) { if (e.target.id === 'sheetbg') closeSheet(); return; }
    const fn = A[t.dataset.a]; if (fn) fn(t.dataset, t, e);
  });
  function onField(e) {
    const t = e.target;
    if (t.dataset.f && draft) { draft[t.dataset.f] = t.value; if (t.dataset.f === 'amount') updateHint(); }
    else if (t.dataset.v && draft) { draft.values[t.dataset.v] = t.value; updateHint(); }
    else if (t.dataset.r && receipt) { receipt[t.dataset.r] = t.dataset.r === 'paidBy' ? t.value : (parseFloat(t.value) || 0); if (e.type === 'change') receiptSheet(); }
    else if (t.dataset.s) { S.settings[t.dataset.s] = t.value.trim(); save(); if (t.dataset.s === 'currency') toast('Currency updated'); }
  }
  document.addEventListener('input', onField);
  document.addEventListener('change', onField);
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter') return;
    if (e.target.id === 'chatin') A.chatSend(); else if (e.target.id === 'q') A.aiFill();
  });
  $('file').addEventListener('change', async (e) => {
    const f = e.target.files && e.target.files[0]; if (!f) return;
    const gid = e.target.dataset.gid; toast('Reading receipt…');
    try {
      const b64 = await fileToB64(f), r = await AI.scanReceipt(aiCfg(), b64, 'image/jpeg'), g = group(gid);
      if (!r.items || !r.items.length) throw new Error('No items found — try a clearer photo');
      receipt = { gid, merchant: r.merchant || '', category: r.category || 'food', tax: +r.tax || 0, tip: +r.tip || 0, paidBy: draft ? draft.paidBy : 'me',
        items: r.items.map((i) => ({ name: String(i.name), price: +i.price || 0, who: g.members.slice() })) };
      draft = null; receiptSheet();
    } catch (err) { toast('Scan failed: ' + err.message); }
  });

  render();
})();
